package org.openml.weka.algorithm;

import weka.gui.GUIChooser;

public class Test {

	public static void main(String[] args) {
		GUIChooser.main(args);
	}
}
