package org.openml.weka.gui;

import weka.gui.experiment.SetupPanel;

public class OpenmlSetupPanel extends SetupPanel {

	/**
	 * this class represents the advanced setup panel of Weka. 
	 * Created for extendability.
	 */
	private static final long serialVersionUID = 860462461269081046L;
	
}
